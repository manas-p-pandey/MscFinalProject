from app.core.database import Base
from app.models import User_Details  # import all models
target_metadata = Base.metadata
